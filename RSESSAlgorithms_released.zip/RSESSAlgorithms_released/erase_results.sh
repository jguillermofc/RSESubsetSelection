#!/bin/bash
rm Results/Approximations/*
rm Results/Times/*
