#!/bin/bash
python3 execute.py
python3 execute_removal.py